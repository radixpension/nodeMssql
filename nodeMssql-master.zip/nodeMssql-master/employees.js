class Employees {
  constructor(Id, First_Name, Last_Name, Email) {
    this.Id = Id;
    this.First_Name = First_Name;
    this.Last_Name = Last_Name;
    this.Email = Email;
    // this.City = City;
  }
}

module.exports = Employees;
